﻿# Teste de estresse automático (Estação 5). O aluno só digita: registrar
#   0 a 60 s    repouso
#   60 a 360 s  carga: o 7-Zip roda sozinho, sem janela (7za b 100)
#   360 a 480 s resfriamento
# Grava clock efetivo, utilização e zona térmica a cada segundo em log_cpu.csv (nesta pasta)
# e, no fim, abre o log no Bloco de Notas. Ctrl+C interrompe e também desliga o 7-Zip.
param([int]$Repouso = 60, [int]$FimCarga = 360, [int]$Fim = 480, [switch]$SemBlocoDeNotas)

$saida = Join-Path $PSScriptRoot 'log_cpu.csv'
$zip   = Join-Path $PSScriptRoot 'extra\x64\7za.exe'
if (-not (Test-Path $zip)) {
    Write-Host 'ERRO: nao achei extra\x64\7za.exe. Rode o preparar.bat (dois cliques) e tente de novo.' -ForegroundColor Red
    exit 1
}
if (Test-Path $saida) { Remove-Item $saida -Force }   # cada teste começa um log novo

Write-Host ''
Write-Host "Teste de estresse automatico: $Fim segundos. Nao mexa no computador." -ForegroundColor Cyan
Write-Host "Gravando em $saida"
Write-Host ''

$inicio = Get-Date
$carga  = $null
try {
    while ($true) {
        $seg = [int]((Get-Date) - $inicio).TotalSeconds
        if ($seg -ge $Fim) { break }

        if ($seg -ge $Repouso -and $seg -lt $FimCarga -and -not $carga) {
            $carga = Start-Process -FilePath $zip -ArgumentList 'b', '100' -WindowStyle Hidden -PassThru
        }
        if ($seg -ge $FimCarga -and $carga -and -not $carga.HasExited) {
            Stop-Process -Id $carga.Id -Force -ErrorAction SilentlyContinue
        }
        if ($seg -lt $Repouso) { $fase = 'repouso      '; $falta = $Repouso - $seg }
        elseif ($seg -lt $FimCarga) { $fase = 'CARGA        '; $falta = $FimCarga - $seg }
        else { $fase = 'resfriamento '; $falta = $Fim - $seg }

        $p = Get-CimInstance Win32_PerfFormattedData_Counters_ProcessorInformation -Filter "Name='_Total'"
        $t = Get-CimInstance Win32_PerfFormattedData_Counters_ThermalZoneInformation -ErrorAction SilentlyContinue |
             Select-Object -First 1
        $linha = [pscustomobject]@{
            Segundo     = $seg
            MHz_efetivo = [math]::Round($p.ProcessorFrequency * $p.PercentProcessorPerformance / 100)
            Utilizacao  = $p.PercentProcessorUtility
            Temp_C      = if ($t) { [math]::Round($t.Temperature - 273.15, 1) } else { '' }
        }
        $linha | Export-Csv $saida -Append -NoTypeInformation -Delimiter ';' -Encoding UTF8
        Write-Host ('{0,4} s  {1} faltam {2,3} s   {3,5} MHz   CPU {4,3}%' -f $seg, $fase, $falta, $linha.MHz_efetivo, $linha.Utilizacao)
        Start-Sleep -Seconds 1
    }
} finally {
    if ($carga -and -not $carga.HasExited) { Stop-Process -Id $carga.Id -Force -ErrorAction SilentlyContinue }
}

Write-Host ''
Write-Host 'Pronto! O log vai abrir no Bloco de Notas: Ctrl+A, Ctrl+C e cole na aba Log CPU (celula A1).' -ForegroundColor Green
if (-not $SemBlocoDeNotas) { Start-Process notepad.exe -ArgumentList "`"$saida`"" }
