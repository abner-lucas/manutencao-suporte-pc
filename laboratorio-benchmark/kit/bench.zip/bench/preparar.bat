@echo off
cd /d "%~dp0"
echo Descompactando o 7-Zip Extra...
7zr.exe x 7z2606-extra.7z -oextra -y
if exist extra\x64\7za.exe (echo Pronto: extra\x64\7za.exe) else (echo ATENCAO: 7za.exe nao encontrado. Use "7zr b" na Estacao 2.)
pause
